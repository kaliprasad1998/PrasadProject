package com.cg.ibs.investment.service;
//import com.cg.ibs.investment.exception;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.InputMismatchException;

import com.cg.ibs.common.bean.TransactionBean;
import com.cg.ibs.common.bean.TransactionType;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.dao.ClientDao;
import com.cg.ibs.investment.dao.InvestmentDaoImpl;
import com.cg.ibs.investment.exception.InsuffBalanceException;
import com.cg.ibs.investment.exception.InvalidAmountException;
import com.cg.ibs.investment.exception.InvalidDetailsException;
import com.cg.ibs.investment.exception.InvalidUnitsException;


public class ClientServiceImpl implements ClientService {
	static long count=0; 
	ClientDao clientdao = new InvestmentDaoImpl();

	@Override
	public HashMap<Integer, BankMutualFund> viewMFPlans() {
		return (clientdao.viewMF());
	}

	@Override
	public double viewGoldPrice() {
		return (clientdao.viewGoldPrice());

	}

	@Override
	public double viewSilverPrice() {
		return (clientdao.viewSilverPrice());

	}

	@Override
	public void buyGold(double gunits, String userId) throws InvalidUnitsException, InsuffBalanceException, InvalidDetailsException,InputMismatchException {
		
		if (gunits > 0 ) {
			InvestmentBean investmentBean = clientdao.viewInvestments(userId);
			if (investmentBean.getBalance() >= gunits * clientdao.viewGoldPrice()) {

				investmentBean.setGoldunits(investmentBean.getGoldunits() + gunits);
				investmentBean.setBalance(investmentBean.getBalance() - gunits * clientdao.viewGoldPrice());

			} else {
				
				throw new InsuffBalanceException("Insufficient balance in your account");
			}

		} else {
			throw new InvalidUnitsException("Please Enter valid weight of Gold");
		}
		}

	@Override
	public void sellGold(double gunits, String userId) throws InvalidUnitsException, InvalidDetailsException, InsuffBalanceException {
		InvestmentBean investmentBean = clientdao.viewInvestments(userId);
		if (gunits > 0) {
			if ( gunits < investmentBean.getGoldunits()) {
				investmentBean.setGoldunits(investmentBean.getGoldunits() - gunits);
				investmentBean.setBalance(investmentBean.getBalance() + gunits * clientdao.viewGoldPrice());
			}else {
				throw new InsuffBalanceException("Insufficient gold units in your account");
			}

			

		} else {
			throw new InvalidUnitsException("Please Enter valid weight of Gold");
		}

	}

	@Override
	public void buySilver(double sunits, String userId)  throws InsuffBalanceException, InvalidUnitsException, InvalidDetailsException {

		if (sunits > 0) {
			InvestmentBean investmentBean = clientdao.viewInvestments(userId);
			if (investmentBean.getBalance() >= sunits * clientdao.viewSilverPrice()) {

				investmentBean.setSilverunits(investmentBean.getSilverunits() + sunits);
				investmentBean.setBalance(investmentBean.getBalance() - sunits * clientdao.viewSilverPrice());

			} else {
				throw new InsuffBalanceException("Insufficient balance in your account");
			}

		} else {
			throw new InvalidUnitsException("Please Enter valid weight of Silver");
		}

	}

	@Override
	public void sellSilver(double sunits, String userId)  throws InvalidUnitsException, InvalidDetailsException, InsuffBalanceException {
		InvestmentBean investmentBean = clientdao.viewInvestments(userId);
		if (sunits > 0) {
			if (sunits < investmentBean.getSilverunits()) {
				investmentBean.setSilverunits(investmentBean.getSilverunits() - sunits);
				investmentBean.setBalance(investmentBean.getBalance() + sunits * clientdao.viewSilverPrice());
			}else {
				throw new InsuffBalanceException("Insufficient silver units in your account");
			}

		} else {
			throw new InvalidUnitsException("Please Enter valid weight of Silver");
		}
	}

	@Override
	public void investMF(double mfAmount, String userId, Integer mfId)  throws InsuffBalanceException, InvalidAmountException, InvalidDetailsException {
		if (mfAmount > 0) {
			if (clientdao.viewMF().containsKey(mfId)) {
				InvestmentBean investmentBean = null;
			
					investmentBean = clientdao.viewInvestments(userId);
				
				double nav = clientdao.viewMF().get(mfId).getNav();
                 
				if (investmentBean.getBalance() >= mfAmount) {
					MutualFund mutualFund=new MutualFund();
					mutualFund.setmfid(mfId);
					mutualFund.setTitle(clientdao.viewMF().get(mfId).getTitle());
					mutualFund.setNav(clientdao.viewMF().get(mfId).getNav());
					LocalDate dt=LocalDate.now();			
			      double mfunits=(mfAmount / nav);
			      mutualFund.setMfUnits(mfunits);
			      mutualFund.setOpeningDate(dt);
			      mutualFund.setStatus(true);
			      
					investmentBean.getFunds().add(mutualFund);
					investmentBean.setFunds(investmentBean.getFunds());						
						
						investmentBean.setBalance(investmentBean.getBalance() - mfAmount);
						/*BigInteger TransactionId=new BigInteger("100100100").add(BigInteger.valueOf(count));
						TransactionBean trxn1=new TransactionBean(TransactionId, TransactionType.DEBIT, dt , BigDecimal.valueOf(mfAmount));
						investmentBean.getTransactionList().add(trxn1);
						investmentBean.setTransactionList(investmentBean.getTransactionList());
					count ++;*/
					

				} else {
					throw new InsuffBalanceException("Insufficient balance in your account");
				}
			}else{
				throw new InvalidDetailsException("Please enter a valid MF plan");
			}
		} else {
			throw new InvalidAmountException("Please enter a valid Amount");
		}
	}

	@Override
	public void withdrawMF( String userId, MutualFund mutualFund) throws InvalidDetailsException   {
		
		if(clientdao.viewInvestments(userId)!=null){
			InvestmentBean investmentBean = clientdao.viewInvestments(userId);
			investmentBean.setBalance(investmentBean.getBalance() + mutualFund.getMfAmount());
			
				investmentBean.getFunds().remove(mutualFund);
				LocalDate dt=LocalDate.now();
			
				/*BigInteger TransactionId=new BigInteger("100100101").add(BigInteger.valueOf(count));
				TransactionBean trxn1=new TransactionBean(TransactionId, TransactionType.CREDIT, dt , BigDecimal.valueOf(mutualFund.getMfAmount()));
				investmentBean.getTransactionList().add(trxn1);
				investmentBean.setTransactionList(investmentBean.getTransactionList());
			count ++;*/
			
		
		}else{
			throw new  InvalidDetailsException("Account not available");
		}
	}

	@Override
	public InvestmentBean viewInvestments(String userId) throws InvalidDetailsException{
		if(clientdao.viewInvestments(userId)!=null){
		return clientdao.viewInvestments(userId);}
		else{
			throw new InvalidDetailsException("Account not available");
		}

	}

	@Override
	public boolean validateCustomer(String userId, String password) throws InvalidDetailsException {
		if(clientdao.viewInvestments(userId)!=null){
		if (userId.equals(clientdao.viewInvestments(userId).getUserId())) {

			String correctPassword = clientdao.viewInvestments(userId).getPassword();
			if (password.equals(correctPassword)) {
				return true;
			}else {
				throw new InvalidDetailsException("Invalid Password");
			}
		}
		}
		else{
			throw new InvalidDetailsException("Invalid Username or password");
		}
		return false;

	}

}
