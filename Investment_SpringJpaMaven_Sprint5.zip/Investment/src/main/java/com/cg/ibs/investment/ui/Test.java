package com.cg.ibs.investment.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import com.cg.ibs.investment.bean.AccountBean;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.InvestmentTransaction;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.bean.TransactionMode;
import com.cg.ibs.investment.bean.TransactionType;
import com.cg.ibs.investment.service.AdditionService;
import com.cg.ibs.investment.service.FetchService;

public class Test {
	
	public static void main(String[] args) {
		/*CustomerService cs=new CustomerServiceImpl();
		try {
			cs.autoSip("user1");
			System.err.println("dfksd");
		} catch (IBSException e) {
			e.printStackTrace();
		}*/
		
		AdditionService as=new AdditionService();
		
		InvestmentTransaction transaction = new InvestmentTransaction();
		FetchService fs = new FetchService();
		AccountBean acc=fs.getAccByAccNum(new BigInteger("12341234123"));
		transaction.setAccount(acc);
		transaction.setPricePerUnit(new Double(3500));
		transaction.setReferenceId("998877");
		transaction.setTransactionDate(LocalDateTime.now());
		transaction.setTransactionDescription("Gold is brought");
		transaction.setTransactionId(123);
		transaction.setTransactionMode(TransactionMode.ONLINE);
		transaction.setTransactionType(TransactionType.DEBIT);
		transaction.setTrxBalance(new BigDecimal(7000));
		transaction.setUnits(new Double(2));
		
		//as.add
	}

}
