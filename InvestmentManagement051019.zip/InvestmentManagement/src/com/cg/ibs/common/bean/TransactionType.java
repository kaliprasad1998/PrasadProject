package com.cg.ibs.common.bean;

public enum TransactionType {
	CREDIT, DEBIT
}
