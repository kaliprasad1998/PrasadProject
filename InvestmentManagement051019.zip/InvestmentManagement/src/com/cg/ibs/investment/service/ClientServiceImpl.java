package com.cg.ibs.investment.service;
//import com.cg.ibs.investment.exception;

import java.util.HashMap;

import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.dao.ClientDao;
import com.cg.ibs.investment.dao.InvestmentDaoImpl;
import com.cg.ibs.investment.exception.InsuffBalanceException;
import com.cg.ibs.investment.exception.InvalidAmountException;
import com.cg.ibs.investment.exception.InvalidDetailsException;
import com.cg.ibs.investment.exception.InvalidUnitsException;

public class ClientServiceImpl implements ClientService {
	ClientDao clientdao = new InvestmentDaoImpl();

	@Override
	public HashMap<String, MutualFund> viewMFPlans() {
		return (clientdao.viewMF());
	}

	@Override
	public double viewGoldPrice() {
		return (clientdao.viewGoldPrice());

	}

	@Override
	public double viewSilverPrice() {
		return (clientdao.viewSilverPrice());

	}

	@Override
	public void buyGold(double gunits, String userId) throws InvalidUnitsException, InsuffBalanceException, InvalidDetailsException {
		if (gunits > 0) {
			InvestmentBean investmentBean = clientdao.viewInvestments(userId);
			if (investmentBean.getBalance() >= gunits * clientdao.viewGoldPrice()) {

				investmentBean.setGoldunits(investmentBean.getGoldunits() + gunits);
				investmentBean.setBalance(investmentBean.getBalance() - gunits * clientdao.viewGoldPrice());

			} else {
				
				throw new InsuffBalanceException("Insufficient balance in your account");
			}

		} else {
			throw new InvalidUnitsException("Please enter a valid number of Gold units");
		}
	}

	@Override
	public void sellGold(double gunits, String userId) throws InvalidUnitsException, InvalidDetailsException, InsuffBalanceException {
		InvestmentBean investmentBean = clientdao.viewInvestments(userId);
		if (gunits > 0) {
			if ( gunits < investmentBean.getGoldunits()) {
				investmentBean.setGoldunits(investmentBean.getGoldunits() - gunits);
				investmentBean.setBalance(investmentBean.getBalance() + gunits * clientdao.viewGoldPrice());
			}else {
				throw new InsuffBalanceException("Insufficient gold units in your account");
			}

			

		} else {
			throw new InvalidUnitsException("Please enter a valid number of Gold units");
		}

	}

	@Override
	public void buySilver(double sunits, String userId)  throws InsuffBalanceException, InvalidUnitsException, InvalidDetailsException {

		if (sunits > 0) {
			InvestmentBean investmentBean = clientdao.viewInvestments(userId);
			if (investmentBean.getBalance() >= sunits * clientdao.viewSilverPrice()) {

				investmentBean.setSilverunits(investmentBean.getSilverunits() + sunits);
				investmentBean.setBalance(investmentBean.getBalance() - sunits * clientdao.viewSilverPrice());

			} else {
				throw new InsuffBalanceException("Insufficient balance in your account");
			}

		} else {
			throw new InvalidUnitsException("Please enter a valid number of Silver units");
		}

	}

	@Override
	public void sellSilver(double sunits, String userId)  throws InvalidUnitsException, InvalidDetailsException, InsuffBalanceException {
		InvestmentBean investmentBean = clientdao.viewInvestments(userId);
		if (sunits > 0) {
			if (sunits < investmentBean.getSilverunits()) {
				investmentBean.setSilverunits(investmentBean.getSilverunits() - sunits);
				investmentBean.setBalance(investmentBean.getBalance() + sunits * clientdao.viewSilverPrice());
			}else {
				throw new InsuffBalanceException("Insufficient sold units in your account");
			}

		} else {
			throw new InvalidUnitsException("Please enter a valid number of Silver units");
		}
	}

	@Override
	public void investMF(double mfAmount, String userId, String mfId)  throws InsuffBalanceException, InvalidAmountException, InvalidDetailsException {
		if (mfAmount > 0) {
			if (clientdao.viewMF().containsKey(mfId)) {
				InvestmentBean investmentBean = null;
				try {
					investmentBean = clientdao.viewInvestments(userId);
				} catch (Exception e) {
					
				}
				double nav = clientdao.viewMF().get(mfId).getNav();
				if (investmentBean.getBalance() >= mfAmount) {
					if(investmentBean.getFunds().containsKey(mfId)){
					double mfunits=investmentBean.getFunds().get(mfId).getMfunits()+(mfAmount / nav);
					investmentBean.getFunds().get(mfId).setMfunits(mfunits);
					
					
					investmentBean.setBalance(investmentBean.getBalance() - mfAmount);}
					else{
						
						investmentBean.getFunds().put(mfId, new MutualFund(mfId,nav,0));
						double mfunits=investmentBean.getFunds().get(mfId).getMfunits()+(mfAmount / nav);
						investmentBean.getFunds().get(mfId).setMfunits(mfunits);
						
						
						investmentBean.setBalance(investmentBean.getBalance() - mfAmount);}
						
					

				} else {
					throw new InsuffBalanceException("Insufficient balance in your account");
				}
			}
		} else {
			throw new InvalidAmountException("Please enter a valid Amount");
		}
	}

	@Override
	public void withdrawMF(double mfamount, String userId, String mfId) throws InvalidAmountException, InvalidDetailsException  {
		if (mfamount > 0) {
			InvestmentBean investmentBean = clientdao.viewInvestments(userId);
			if (investmentBean.getFunds().containsKey(mfId)) {
				
				double nav = clientdao.viewMF().get(mfId).getNav();
				double mfunits=investmentBean.getFunds().get(mfId).getMfunits() - mfamount / nav;
				investmentBean.getFunds().get(mfId).setMfunits(mfunits);

				investmentBean.setBalance(investmentBean.getBalance() + mfamount);
			}
		} else {
			throw new InvalidAmountException("Please enter a valid amount");
		}

	}

	@Override
	public InvestmentBean viewInvestments(String userId) throws InvalidDetailsException{
		if(clientdao.viewInvestments(userId)!=null){
		return clientdao.viewInvestments(userId);}
		else{
			throw new InvalidDetailsException("Account not available");
		}

	}

	@Override
	public boolean validateCustomer(String userId, String password) throws InvalidDetailsException {
		if(clientdao.viewInvestments(userId)!=null){
		if (userId.equals(clientdao.viewInvestments(userId).getUserId())) {

			String correctPassword = clientdao.viewInvestments(userId).getPassword();
			if (password.equals(correctPassword)) {
				return true;
			}
		}
		}
		else{
			throw new InvalidDetailsException("Invalid Username or Password");
		}
		return false;

	}

}
