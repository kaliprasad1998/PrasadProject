package com.cg.ibs.investment.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class InvestmentController {
	
	@RequestMapping({"/","/home"})
	public String showHome(){
		return "homePage";
	}

	@RequestMapping("/menu")
	public String showMenu(){
		return "menuPage";
	}
}
