package com.cg.ibs.investment.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MFType;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.CustomerService;

@Controller
public class CustomerController {
	private String userId = "user1";

	@Autowired
	private CustomerService service;

	@RequestMapping("/customer")
	public ModelAndView showDeptsHome() {
		return new ModelAndView("customerLogin");
	}

	@RequestMapping("/custLogin")
	public ModelAndView customerLogin(@RequestParam("userId") String userId,
			@RequestParam("password") String password) {
		ModelAndView modelAndView = new ModelAndView();
		if (service.validateCustomer(userId, password)) {
			modelAndView = new ModelAndView("customerMenu");
		}
		return modelAndView;
	}

	@RequestMapping("/viewMyInvestment")
	public ModelAndView viewMyInvestments() {
		ModelAndView mv = new ModelAndView();
		Set<MutualFund> dirset = new HashSet<MutualFund>();
		Set<MutualFund> sipset = new HashSet<MutualFund>();
		try {
			InvestmentBean bean = service.viewInvestments(userId);
			mv.addObject("uci", bean.getUCI());
			mv.addObject("goldunits", bean.getGoldunits());
			mv.addObject("silverunits", bean.getSilverunits());
			for (MutualFund mf : bean.getFunds()) {
				if (mf.getType() == MFType.DIRECT) {
					dirset.add(mf);
				} else {
					sipset.add(mf);
				}
			}
			mv.addObject("directMf", dirset);
			mv.addObject("sipmf", sipset);
		} catch (IBSException e) {
			e.printStackTrace();
		}
		mv.setViewName("viewMyInvestment");
		return mv;
	}

	@RequestMapping("/viewGoldPrice")
	public ModelAndView viewGoldPrice() {
		ModelAndView mv = new ModelAndView();
		try {
			mv.addObject("price", service.viewGoldPrice());
		} catch (IBSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.setViewName("customerMenu");
		return mv;

	}

	@RequestMapping("/viewSilverPrice")
	public ModelAndView viewSilverPrice() {
		ModelAndView mv = new ModelAndView();
		try {
			mv.addObject("price", service.viewSilverPrice());
		} catch (IBSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.setViewName("customerMenu");
		return mv;

	}

	@RequestMapping("/viewMyTransactions")
	public ModelAndView viewMyTransactions() {
		ModelAndView mv = new ModelAndView();
		try {

			mv.addObject("transactions", service.getTransactions(userId));

		} catch (IBSException e) {
			e.printStackTrace();
		}
		mv.setViewName("viewMyTransactions");
		return mv;
	}

	@RequestMapping({ "/buyGold", "/sellGold" })
	public ModelAndView buyGold() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("GoldPage");
		return mv;
	}

	@RequestMapping("/buygold")
	public ModelAndView buyGoldMethod(@RequestParam("goldUnits") Double goldUnits) {
		try {
			service.buyGold(goldUnits, userId);
		} catch (IBSException e) {
			e.printStackTrace();
		}
		return new ModelAndView("customerMenu");
	}

	@RequestMapping("/sellgold")
	public ModelAndView sellGoldMethod(@RequestParam("goldUnits") Double goldUnits) {
		try {
			service.sellGold(goldUnits, userId);
		} catch (IBSException e) {
			e.printStackTrace();
		}
		return new ModelAndView("customerMenu");
	}

	@RequestMapping({ "/buySilver", "/sellSilver" })
	public ModelAndView buySilver() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("SilverPage");
		return mv;
	}

	@RequestMapping("/silverbuy")
	public ModelAndView buySilverMethod(@RequestParam("silverUnits") Double silverUnits) {
		try {
			service.buySilver(silverUnits, userId);
		} catch (IBSException e) {
			e.printStackTrace();
		}
		return new ModelAndView("customerMenu");
	}

	
	  @RequestMapping("/silversell") public ModelAndView
	  sellSilverMethod(@RequestParam("silverUnits") Double silverUnits) { try {
	  service.sellSilver(silverUnits, userId); } catch (IBSException e) {
	  e.printStackTrace(); } return new ModelAndView("customerMenu"); }
	 

	@RequestMapping("/investDirect")
	public ModelAndView investMf() {
		return new ModelAndView("investFormPage");
	}
}