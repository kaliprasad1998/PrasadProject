package com.cg.ibs.investment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.BankService;
import com.cg.ibs.investment.service.CustomerService;

@Controller
public class BankController {
	@Autowired
	private CustomerService service;
	@Autowired
	private BankService bankService;
	
	@RequestMapping("/bank")
	public ModelAndView showBankLogin(){
		ModelAndView mv = new ModelAndView();
		mv.setViewName("bankLogin");
		return mv;
	}
	@RequestMapping(method = RequestMethod.POST,value = "/bankLogin")
	public ModelAndView bankLogin(@RequestParam("userId") String userId, @RequestParam("password") String password ){
		Boolean result;
		ModelAndView mv = new ModelAndView();
		try {
			result = bankService.validateBank(userId, password);
			if(result==true){
				mv.setViewName("bankMenu");
			}else {
				mv.setViewName("showMessage");
			}
		} catch (IBSException e) {
			mv.setViewName("showMessage");
		}
		
		return mv;
	}
	@RequestMapping("/bankGold")
	public ModelAndView manageGold() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("bankGoldMenu");
		return mv;
	}
	
	@RequestMapping("/viewGPrice")
	public ModelAndView viewGoldPrice() {
		ModelAndView mv = new  ModelAndView();
		try {
			mv.addObject("goldPrice",service.viewGoldPrice());
			mv.setViewName("viewGoldPrice");
		} catch (IBSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mv;
	}
	
	@RequestMapping("/updateGPrice")
	public ModelAndView updateGoldPriceView() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("updateGoldPrice");
		return mv;
	}
	
	@RequestMapping("/updateGoldPricemethod")
	public ModelAndView updateGoldPrice(@RequestParam("goldPrice") Double goldPrice) {
		ModelAndView mv = new ModelAndView();
		Boolean result;
		 
		try {
			result =bankService.updateGoldPrice(goldPrice);
			if(result==true) {
				mv.addObject("message","Gold Price updated successfully");
				mv.setViewName("bankMenu");
			}else {
				mv.addObject("message","Gold Price is already updated today");
				mv.setViewName("bankMenu");
			}
			
		} catch (IBSException e) {
			e.printStackTrace();
			}
		return mv;
	}
	
	@RequestMapping("/bankSilver")
	public ModelAndView manageSilver() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("bankSilverMenu");
		return mv;
	}
	
	@RequestMapping("/viewSPrice")
	public ModelAndView viewSilverPriceView() {
		ModelAndView mv = new ModelAndView();
		try {
			mv.addObject("silverPrice",service.viewSilverPrice());
			mv.setViewName("viewSilverPrice");
		} catch (IBSException e) {
			e.printStackTrace();
		}
		return mv;
	}
	
	@RequestMapping("/updateSPrice")
	public ModelAndView updateSilverPriceView() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("updateSilverPrice");
		return mv;
	}
	
	@RequestMapping("/updateSilverPriceMethod")
	public ModelAndView updateSilverprice(@RequestParam("silverPrice") Double silverPrice) {
		ModelAndView mv = new ModelAndView();
		Boolean result;
		try {
			result = bankService.updateSilverPrice(silverPrice);
			if (result==true) {
				mv.addObject("message","Silver Price updated successfully");
				mv.setViewName("bankMenu");
			} else {
				mv.addObject("message","Silver Price is already updated today");
				mv.setViewName("bankMenu");
			}
		} catch (IBSException e) {
			e.printStackTrace();
		}
		return mv;
	}
	
	@RequestMapping("/bankMfMenu")
	public ModelAndView manageMutualFunds() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("bankMfMenu");
		return mv;
	}
	
	@RequestMapping("/addMutualFund")
	public ModelAndView addMutualFund() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("addMutualFund");
		return mv;
	}
	
	
	
}
